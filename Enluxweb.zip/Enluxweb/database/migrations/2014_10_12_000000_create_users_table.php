<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
          $table->bigIncrements('id');
          $table->string('name');
          $table->string('username');
          $table->string('email')->nullable();
          $table->timestamp('email_verified_at')->nullable();
          $table->string('password');
          $table->string('phone')->nullable();
          $table->string('api_token',60)->unique()->nullable();
          $table->tinyInteger('is_permission')->default('2'); //admin,staff
          $table->string('attend')->nullable();
          $table->string('ch_by')->nullable();
          $table->string('avatar')->nullable();
          $table->rememberToken();
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
